import React from "react"

const Dashboard = () => {
  return <div />
}

export default Dashboard
