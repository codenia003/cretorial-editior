export { default as default } from "./Graphic"
