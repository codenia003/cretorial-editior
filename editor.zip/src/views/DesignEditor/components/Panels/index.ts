import Panels from "./Panels"
export default Panels
