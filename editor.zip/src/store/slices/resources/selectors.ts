import { RootState } from "~/store/rootReducer"

export const selectPixabayResources = (state: RootState) => state.resources.pixabay
