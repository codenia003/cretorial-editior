export { default as default } from "./LazyLoadImage"
