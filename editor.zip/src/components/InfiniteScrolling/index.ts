export { default as default } from "./InfiniteScrolling"
