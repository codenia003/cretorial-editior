import DropZone from './DropZone'

export default DropZone
